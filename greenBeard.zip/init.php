<?php
	define('PATH_TO_ROOT', '/opt/lampp/htdocs/greenBeard');
	define('PATH_TO_PRESENTATION_LAYER', '/opt/lampp/htdocs/greenBeard/Presentation');
	define('PATH_TO_TEMPLATES', '/opt/lampp/htdocs/greenBeard/Presentation/templates');  
?>