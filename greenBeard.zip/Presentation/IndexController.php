<?php

import('Presentation.Command');


class IndexController extends Command{
	public function execute(array $content):array{
		return [];
	}
	
	
}