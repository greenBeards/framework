<?php
interface iListener{
	public function applyModifications(Object $object);	
}

?>