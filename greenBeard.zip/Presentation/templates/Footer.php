<?php

class Footer{
    public function toHtml(){
        $toHtml="
            </body>
        </html>";
        return $toHtml;
    }
}
?>